# بستهٔ استقرار پالس برای Hostinger

این بسته برای Node.js App در Hostinger آماده شده و شامل frontend، API، launcher و فایل کامل SQL قدیمی است.

## نصب روی Hostinger

1. محتوای ZIP را Upload و Extract کنید.
2. نسخهٔ Node.js را روی ۲۰ یا بالاتر بگذارید.
3. در تنظیمات Node.js این مقادیر را تنظیم کنید:
   - **Application startup file:** `launcher.mjs`
   - **Application root:** پوشه‌ای که `launcher.mjs` داخل آن است
   - **Application URL:** دامنه یا subdomain موردنظر
4. متغیرهای بخش بعد را در **Environment Variables** بسازید.
5. برنامه را Restart کنید.

## متغیرهای Environment

### ضروری

- `DATABASE_URL`: آدرس کامل PostgreSQL قابل‌دسترسی از Hostinger. نمونه:
  `postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require`
- `SESSION_SECRET`: یک رشتهٔ تصادفی طولانی. این مقدار هم sessionهای ورود را محافظت می‌کند و هم credentialهای Provider ذخیره‌شده در Settings را رمزنگاری می‌کند.
- `TELEGRAM_BOT_TOKEN`: توکن Bot تلگرام برای اعتبارسنجی ورود.

### ورود مدیر اصلی

- `TELEGRAM_MASTER_ADMIN_ID`: شناسهٔ عددی تلگرام مدیر اصلی؛ مقدار پیش‌فرض `1026368027` است و فقط در صورت نیاز تغییر دهید.

### اجرای برنامه و migration

- `PORT`: پورت عمومی که Hostinger اختصاص می‌دهد؛ معمولاً همان مقدار پیشنهادی Hostinger را نگه دارید.
- `API_INTERNAL_PORT`: پورت داخلی API؛ معمولاً `PORT + 1` و روی `3001`.
- `AUTO_MIGRATE_LEGACY_SQL`: به‌صورت پیش‌فرض `true`. در اولین اجرا فایل کامل `legacy/legacy.sql` را فقط اگر marker migration وجود نداشته باشد وارد PostgreSQL می‌کند.
- `LEGACY_SQL_PATH`: اختیاری؛ فقط اگر فایل SQL را به مسیر دیگری منتقل کردید تنظیم کنید.

### اختیاری

- `SUBSCRIPTION_UPSTREAM_BASE_URL`: آدرس legacy برای لینک‌های اشتراک قدیمی.
- `LEGACY_SUBSCRIPTION_BASE_URL`: fallback همان آدرس.
- `USAGE_SYNC_INTERVAL_MS`: فاصلهٔ همگام‌سازی مصرف به میلی‌ثانیه؛ پیش‌فرض `60000`.

## تنظیم Providerها داخل خود اپ

بعد از ورود با حساب مدیر اصلی:

1. به **Settings / تنظیمات** بروید.
2. در بخش **تنظیم Providerهای V2Box** Provider را فعال کنید.
3. نوع Provider و `API URL` را وارد کنید.
4. برای Providerهای Rain Admin یا Marzban، username و password را در همان فرم وارد کنید.
5. برای Falcon، API key را در همان فرم وارد کنید.
6. روی «ذخیره در دیتابیس» بزنید.

Credentialها در سمت سرور با AES-256-GCM رمزنگاری می‌شوند و مقدارشان به frontend برگردانده نمی‌شود. بنابراین برای Providerها نیازی به `RAIN_*` یا `FALCO_API_KEY` در Environment ندارید.

## migration خودکار کامل SQL

فایل `legacy/legacy.sql` همان dump کامل MariaDB/MySQL است. Launcher قبل از API این مراحل را انجام می‌دهد:

1. اتصال به PostgreSQL را با `DATABASE_URL` برقرار می‌کند.
2. جدول‌های legacy را با تبدیل امن MySQL/MariaDB به PostgreSQL می‌سازد.
3. داده‌های همهٔ جدول‌ها را در transaction وارد می‌کند.
4. migration را با marker ثبت می‌کند تا در restart دوباره اجرا نشود.
5. سپس API و workerها را بالا می‌آورد.

در اولین اجرا، بسته به اندازهٔ دیتابیس ممکن است چند دقیقه زمان نیاز باشد. در صورت خطا، API شروع نمی‌شود تا migration ناقص پنهان نماند.

## تست بعد از نصب

- دامنه را باز کنید؛ صفحهٔ ورود نمایش داده می‌شود.
- وارد Settings شوید و Providerها را از داخل اپ ذخیره کنید.
- یک سرویس آزمایشی بسازید.
- تب Monitoring را برای وضعیت Provider و migration/retry بررسی کنید.

مقادیر واقعی password، token و `DATABASE_URL` داخل این ZIP قرار داده نشده‌اند.
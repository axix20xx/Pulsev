# بستهٔ استقرار پالس برای Hostinger

این بسته برای Node.js App در Hostinger آماده شده است و شامل frontend build‌شده، API build‌شده و launcher یکپارچه است.

## نصب

1. محتوای این ZIP را در پوشهٔ برنامهٔ Node.js در Hostinger آپلود و Extract کنید.
2. نسخهٔ Node.js را روی ۲۰ یا بالاتر بگذارید.
3. در تنظیمات Node.js:
   - **Application startup file:** `launcher.mjs`
   - **Application root:** پوشه‌ای که `launcher.mjs` داخل آن است
   - **Application URL:** دامنه یا subdomain موردنظر
4. متغیرهای `.env.example` را در بخش Environment Variables هاست بسازید.
5. مقدار واقعی `DATABASE_URL`، `SESSION_SECRET`، `TELEGRAM_BOT_TOKEN` و credentialهای Providerها را فقط در همان بخش Hostinger وارد کنید.
6. برنامه را Restart کنید.

## متغیرهای مهم

- `DATABASE_URL`: اتصال PostgreSQL قابل‌دسترسی از Hostinger؛ بدون آن API اجرا نمی‌شود.
- `SESSION_SECRET`: یک مقدار تصادفی طولانی برای sessionها.
- `TELEGRAM_BOT_TOKEN`: برای ورود تلگرام.
- `RAIN_PHONEPANEL_USER` و `RAIN_PHONEPANEL_PASS`
- `RAIN_SPEEDUR_USER` و `RAIN_SPEEDUR_PASS`
- `RAIN_XXPANEL_USER` و `RAIN_XXPANEL_PASS`
- `FALCO_API_KEY` در صورت استفاده از Falcon

مقدارهای واقعی Secret در این ZIP قرار داده نشده‌اند.

## نکتهٔ شبکه

Hostinger باید بتواند به PostgreSQL، Telegram و آدرس Providerها دسترسی خروجی داشته باشد. اگر یک Provider مثل speedur از DNS یا شبکهٔ Hostinger قابل‌دسترسی نباشد، سرویس در Providerهای سالم ساخته می‌شود و retry آن در تب Monitoring انجام خواهد شد.

## تست

- باز کردن دامنه باید صفحهٔ ورود پالس را نشان دهد.
- مسیر `/api/auth/session` باید پاسخ API بدهد.
- بعد از ورود، تب «مانیتورینگ» وضعیت jobهای ساخت سرویس را نمایش می‌دهد.
# Morrow Gift Card Showcase — Hostinger Package

This is a Hostinger-ready static package for the Morrow gift-card showcase.

## Upload

Upload the contents of this ZIP to the domain's `public_html/` directory. The root `index.html`, `assets/`, `.htaccess`, icons, and manifest are the live website bundle.

The included `webapp/` directory contains the editable React/Vite source for future changes; it is not required for the live static site.

## Routes

- `/` — public landing page
- `/login` — local demo login
- `/showcase` — protected demo showcase

The `.htaccess` file keeps these client-side routes working after refresh on Apache hosting.

## Important

This is a showcase-only frontend. It does not process payments, sell gift cards, or require a backend. Login uses a browser-local demo session.

## Rebuild in the workspace

```bash
pnpm install
PORT=18828 BASE_PATH=/ pnpm --filter @workspace/gift-card-showcase run build
```

# Gift Card Showcase — Full Webapp Package

This package contains the complete `webapp/` directory for the Morrow gift card showcase.

Included:

- Full React + Vite source code
- Production build in `webapp/dist/public/`
- Public landing page
- Browser login at `/gift-card-showcase/login`
- Protected demo showcase at `/gift-card-showcase/showcase`
- Morrow logo and brand mark
- Favicon and Apple touch icon
- iOS/PWA manifest
- Vite and artifact configuration

## Run inside the Replit workspace

From the workspace root:

```bash
pnpm --filter @workspace/gift-card-showcase run typecheck
PORT=18828 BASE_PATH=/gift-card-showcase/ pnpm --filter @workspace/gift-card-showcase run build
```

## Preview the built webapp

The Replit artifact serves the built files from `webapp/dist/public/` with the configured `/gift-card-showcase/` base path.

This is a showcase-only app. It does not process payments or sell gift cards.
